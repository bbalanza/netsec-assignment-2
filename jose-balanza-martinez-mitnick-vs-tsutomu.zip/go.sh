#!/usr/bin/env bash

make
sudo ./attack
