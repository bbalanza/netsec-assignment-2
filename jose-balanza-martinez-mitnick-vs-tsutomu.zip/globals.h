#include <libnet.h>
#include <netinet/ether.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <pcap.h>
#include <stdio.h>
#include <string.h>
#define GLOBALS_H
#define STRING_BUFF_SIZE 128
#define ETHERNET_HEADER_LENGTH 14
